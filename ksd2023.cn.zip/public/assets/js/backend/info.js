define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'info/index' + location.search,
                    add_url: 'info/add',
                    edit_url: 'info/edit',
                    del_url: 'info/del',
                    multi_url: 'info/multi',
                    import_url: 'info/import',
                    table: 'info',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'pmid', title: __('Pmid')},
                        {field: 'type', title: __('Type'), operate: 'LIKE'},
                        {field: 'therapy', title: __('Therapy'), operate: 'LIKE'},
                        {field: 'biomarkertype', title: __('Biomarkertype'), operate: 'LIKE'},
                        {field: 'biomarker', title: __('Biomarker'), operate: 'LIKE'},
                        {field: 'geneid', title: __('Geneid'), operate: 'LIKE'},
                        {field: 'symbol', title: __('Symbol'), operate: 'LIKE'},
                        {field: 'drug', title: __('Drug'), operate: 'LIKE'},
                        {field: 'drugbank', title: __('Drugbank'), operate: 'LIKE'},
                        {field: 'target', title: __('Target'), operate: 'LIKE'},
                        {field: 'suppressor', title: __('Suppressor'), operate: 'LIKE'},
                        {field: 'expression', title: __('Expression'), operate: 'LIKE'},
                        {field: 'detecting', title: __('Detecting'), operate: 'LIKE'},
                        {field: 'url', title: __('Url'), operate: 'LIKE', formatter: Table.api.formatter.url},
                        {field: 'journal', title: __('Journal'), operate: 'LIKE'},
                        {field: 'year', title: __('Year')},
                        {field: 'title', title: __('Title'), operate: 'LIKE'},
                        {field: 'authors', title: __('Authors'), operate: 'LIKE'},
                        {field: 'keywords', title: __('Keywords'), operate: 'LIKE'},
                        {field: 'country', title: __('Country'), operate: 'LIKE'},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
